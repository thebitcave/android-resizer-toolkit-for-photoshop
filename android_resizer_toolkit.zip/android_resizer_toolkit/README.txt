Thanks for downloading this little utility for Photoshop CS6.

To install it, simply double click the .zxp package (you will need Adobe Extension Manager CS6 or CS5).

Restart Photoshop and open the panel by selecting: Window > Extensions > Android Resizer Toolkit.

mail: thebitcave@gmail.com
web: thebitcave.com
twitter: thebitcave
